//Name: Isaac Blackwood
//Net ID: idb170030
package Redbox;

public class DataFileFormatException extends Exception 
{
	private static final long serialVersionUID = 3780175544161766315L;
}
