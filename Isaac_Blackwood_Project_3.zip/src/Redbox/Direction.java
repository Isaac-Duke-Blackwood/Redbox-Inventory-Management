//Name: Isaac Blackwood
//Net ID: idb170030
package Redbox;

public enum Direction 
{
	LEFT, RIGHT;
}
